/*
 * Test dla zadania Kolokwium 20/02/2024 - zadanie na 3,0
 * Autor testowanej odpowiedzi: Bartosz Wijata
 * Test wygenerowano automatycznie o 2024-02-20 18:18:51.099347
 *
 * Debug: { { test|pprint } }
 */

#if !defined(_TESTED_DECLARATIONS_H_)
#define _TESTED_DECLARATIONS_H_

// Wymagane deklaracji testowanych funkcji oraz zapowiedzi typów/struktur,
// które muszą znajdować się w kodzie przesłanym przez Studenta


        #include "defs.h"
        #include <stdint.h>

        int count01_int(int);  
    

#endif // _TESTED_DECLARATIONS_H_